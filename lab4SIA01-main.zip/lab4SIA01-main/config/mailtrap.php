<?php
// /config/mailtrap.php

define('MAILTRAP_HOST', 'sandbox.smtp.mailtrap.io');
define('MAILTRAP_PORT', 2525); // Mailtrap standard port
define('MAILTRAP_USERNAME', 'PUT_SMTP_USERNAME_HERE'); // From Mailtrap Inbox
define('MAILTRAP_PASSWORD', 'PUT_SMTP_PASSWORD_HERE'); // From Mailtrap Inbox

// API Token for the cURL method you prefer
define('MAILTRAP_API_TOKEN', 'ba986166833b2a2585915be1f6844332'); 

define('MAILTRAP_FROM_EMAIL', 'hello@demomailtrap.co');
define('MAILTRAP_FROM_NAME', 'Legacy Store');

define('ADMIN_EMAIL', 'agustin.johnmichael@student.auf.edu.ph');
define('SUPPORT_EMAIL', 'support@legacycms.local');